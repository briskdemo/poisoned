BOT_TOKEN = "7703903703:AAEvbYq_UFLxWGis2lfpT823_UNe3qZiYR0"

GROUP_USERNAME = "allmalltoi"
JOIN_REQUIRED_GROUP = "ppbackup01"
BACKUP_GROUP_LINK = "https://t.me/ppbackup01"
MEDIA_GROUP_ID = -1002635316441  # your actual @allmalltoi chat ID


ADMIN_ID = 7141876350
ADMIN_USERNAME = "@Userinvalidcredits"

from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

bot_properties = DefaultBotProperties(parse_mode=ParseMode.HTML)
